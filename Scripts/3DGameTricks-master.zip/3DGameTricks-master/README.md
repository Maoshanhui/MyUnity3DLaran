# 3DGameTricks
This is the samples in the book,(Tricks of the 3D Game Programming Gurus-Advanced 3D Graphics and Rasterization). I use vs2015 to create samples project.  You can use it when you want 3d game programming.
