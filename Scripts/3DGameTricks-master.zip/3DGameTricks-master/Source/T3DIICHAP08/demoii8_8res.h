//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by demoII8_8.rc
//
#define IDR_ASCMENU                     101
#define IDD_DIALOG1                     102
#define IDC_EDIT1                       1000
#define IDC_SWAPYZ                      1001
#define IDC_IWINDING                    1002
#define ID_FILE_LOADASCFILE             40001
#define ID_FILE_EXIT                    40002
#define ID_LIGHTS_TOGGLEAMBIENTLIGHT    40004
#define ID_LIGHTS_TOGGLEPOINTLIGHT      40005
#define ID_LIGHTS_TOGGLESPOTLIGHT       40006
#define ID_ZSORTING_ENABLE              40007
#define ID_ZSORTING_DISABLE             40009
#define ID_ENABLE_DISABLE               40010
#define ID_BACKFACEREMOVAL_ENABLE       40010
#define ID_BACKFACEREMOVAL_DISABLE      40011
#define ID_HELP_ABOUT                   40012
#define ID_LIGHTS_TOGGLEINFINITELIGHT   40014
#define ID_RENDERINGMODE_SOLID          40017
#define ID_RENDERINGMODE_WIREFRAME      40018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40019
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
