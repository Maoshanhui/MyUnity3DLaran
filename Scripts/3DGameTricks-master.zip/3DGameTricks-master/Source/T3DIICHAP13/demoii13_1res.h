//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by demoII13_1.rc
//
#define IDR_ASCMENU                     101
#define IDR_COBMENU                     101
#define IDR_BSPMENU                     101
#define IDD_DIALOG1                     102
#define IDD_DIALOG2                     103
#define IDC_EDIT1                       1000
#define IDC_SWAPYZ                      1001
#define IDC_OPTION1                     1001
#define IDC_IWINDING                    1002
#define IDC_OPTION2                     1002
#define IDC_LOCAL                       1003
#define IDC_OPTION3                     1003
#define IDC_WORLD                       1004
#define IDC_OPTION4                     1004
#define ID_FILE_LOADASCFILE             40001
#define ID_FILE_LOADCOBFILE             40001
#define ID_FILE_LOAD_LEV                40001
#define ID_FILE_EXIT                    40002
#define ID_LIGHTS_TOGGLEAMBIENTLIGHT    40004
#define ID_BUILD_TO_FILE                40004
#define ID_LIGHTS_TOGGLEPOINTLIGHT      40005
#define ID_LIGHTS_TOGGLESPOTLIGHT       40006
#define ID_ZSORTING_ENABLE              40007
#define ID_ZSORTING_DISABLE             40009
#define ID_ENABLE_DISABLE               40010
#define ID_BACKFACEREMOVAL_ENABLE       40010
#define ID_BACKFACEREMOVAL_DISABLE      40011
#define ID_HELP_ABOUT                   40012
#define ID_LIGHTS_TOGGLEINFINITELIGHT   40014
#define ID_BUILD_TO_SCREEN              40014
#define ID_COMPILE_VIEW                 40014
#define ID_RENDERINGMODE_SOLID          40017
#define ID_RENDERINGMODE_WIREFRAME      40018
#define ID_FILE_SAVE_LEV                40019
#define IDC_VIEWGRID                    40020
#define IDC_VIEWWALLS                   40022
#define IDC_VIEWFLOORS                  40023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40025
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
