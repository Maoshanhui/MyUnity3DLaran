README.TXT for \source directory

"Tricks of the 3D Game Programming Gurus-Advanced 3D Graphics and Rasterization"
Created: 1.1.03 by Andre' LaMothe

Within this directory you will find all the source directories for the demos and programs
of the book. Simply copy this entire directory to your hard drive, decompress each source
directory if necessary, and you have everything you need to work thru the book.

Also, each directory has numerous .exe files for the demos. In most cases, you can simply
launch the .exe and the demo will run perfectly.


