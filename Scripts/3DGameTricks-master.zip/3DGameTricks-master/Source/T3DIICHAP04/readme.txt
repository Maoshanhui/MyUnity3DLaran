README.TXT 

"Tricks of the 3D Game Programming Gurus-Advanced 3D Graphics and Rasterization"
Created: 1.1.03 by Andre' LaMothe

This directory intentionally left empty.
