      Construction of the Warhammer battlemech, which
was designed primarily as an assault 'mech, began in
2515 and continued up until after the fall of the Star League.
The origional requsition by General Sternson to StarCorp
Industries called for "a mobile 'Mech with enough
firepower to destroy or severly damage any 'Mech of
the same weight class or lower".  StarCorp's answer was
the Warhammer.  There were several different production
runs of the mech, including the Class 6D and the Class
6K.  In the current era, several modified versions have
also been developed within the successor States






well thats the description of the model its kinda youre average mecha thingie but this is from battletech  any resemblance to macross mecha are unfortunate and unintentional  (  ;P to macross  )
