Web:   http://members.home.com/droyer/index.html
Email: aggravated@bigfoot.com
ICQ:   4491034
Name:  Dan Royer
